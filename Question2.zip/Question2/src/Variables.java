
public class Variables {
	
	//instance variable
	int instanceVar;
	
	//static variable
	static int data = 99;
	
	//constructor
	public Variables(int instanceVar) {
		this.instanceVar = instanceVar;
		System.out.println("instance variable = " + this.instanceVar);
		
	}
	
	//non static method
	public void localVar() {
				
		//local variable
		int local = 80;
		System.out.println("local variable from method = "+ local);
	}
	
	//THE MAIN METHOOODDDDD!!
	public static void main(String[] args) {
		
		//creating the object w/ parameter
		Variables obj = new Variables(10);
		
		obj.localVar();
		System.out.println("Class variable = " + Variables.data);
	}
}